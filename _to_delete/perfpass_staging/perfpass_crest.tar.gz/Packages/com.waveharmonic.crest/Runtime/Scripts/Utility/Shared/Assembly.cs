// Crest Water System
// Copyright © 2024 Wave Harmonic. All rights reserved.

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("WaveHarmonic.Crest")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Integration.Gaia")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Shared.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples.Boats")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples.Examples")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples.Ripples")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples.Waterfall")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Samples.Submarine")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.CPUQueries")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.CPUQueries.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Paint")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Paint.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.ShallowWater")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.ShallowWater.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.ShiftingOrigin")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.ShiftingOrigin.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Splines")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Splines.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Watercraft")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Watercraft.Editor")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Whirlpool")]
[assembly: InternalsVisibleTo("WaveHarmonic.Crest.Whirlpool.Editor")]

// Define empty namespaces for when assemblies are not present.
namespace UnityEditor.SceneManagement { }
namespace UnityEngine.Rendering.HighDefinition { }
namespace UnityEngine.Rendering.Universal { }
